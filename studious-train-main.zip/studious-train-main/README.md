I just try to make a tool for someone who want to think twice about driving at high speed
